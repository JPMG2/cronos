<?php

declare(strict_types=1);

namespace NunoMaduro\PhpInsights\Domain\InsightLoader;

use NunoMaduro\PhpInsights\Domain\Collector;
use NunoMaduro\PhpInsights\Domain\Contracts\Insight;
use NunoMaduro\PhpInsights\Domain\Contracts\InsightLoader;
use NunoMaduro\PhpInsights\Domain\Insights\SniffDecorator;
use PHP_CodeSniffer\Sniffs\Sniff as SniffContract;

/**
 * @internal
 */
final class SniffLoader implements InsightLoader
{
    public function support(string $insightClass): bool
    {
        $interfaces = class_implements($insightClass);
        if (!is_array($interfaces)) {
            return false;
        }
        return array_key_exists(SniffContract::class, $interfaces);
    }

    public function load(string $insightClass, string $dir, array $config, Collector $collector): Insight
    {
        /** @var SniffContract $sniff */
        $sniff = new $insightClass();

        $excludeConfig = [];

        if (isset($config['exclude'])) {
            /** @var array<string> $excludeConfig */
            $excludeConfig = $config['exclude'];
            unset($config['exclude']);
        }

        foreach ($config as $property => $value) {
            if (property_exists($sniff, $property)) {
                $sniff->{$property} = $value;
            }
        }

        return new SniffDecorator($sniff, $dir, $excludeConfig);
    }
}
